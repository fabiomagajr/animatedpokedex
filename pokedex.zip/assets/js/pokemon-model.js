
class Pokemon {
    number;
    name;
    type;
    types = [];
    photo;
    backphoto;
    frontphoto;
    stats=[];
    stat;
    hp;
    atk;
    def;
    sp_atk;
    sp_def;
    speed;


    abilities=[];
    ability;
}
